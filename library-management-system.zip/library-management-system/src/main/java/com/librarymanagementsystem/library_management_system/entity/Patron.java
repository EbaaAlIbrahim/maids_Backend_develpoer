package com.librarymanagementsystem.library_management_system.entity;


import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Patron {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key

    private String name;  // Name of the patron
    private String contactInformation;  // Contact details
}