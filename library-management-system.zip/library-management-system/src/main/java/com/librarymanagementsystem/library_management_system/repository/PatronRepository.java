package com.librarymanagementsystem.library_management_system.repository;

import com.librarymanagementsystem.library_management_system.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PatronRepository extends JpaRepository<Patron, Long> {}

    
