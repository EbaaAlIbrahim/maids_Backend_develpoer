package com.librarymanagementsystem.library_management_system.service;


import com.librarymanagementsystem.library_management_system.entity.Patron;
import com.librarymanagementsystem.library_management_system.repository.PatronRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatronService {
    @Autowired
    private PatronRepository patronRepository;

    public Patron addPatron(Patron patron) {
        return patronRepository.save(patron);
    }

    public List<Patron> getAllPatrons() {
        return patronRepository.findAll();
    }

    public Patron getPatronById(Long id) {
        return patronRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patron not found"));
    }

    public void deletePatronById(Long id) {
        if (!patronRepository.existsById(id)) {
            throw new RuntimeException("Patron not found");
        }
        patronRepository.deleteById(id);
    }

    public void deleteAllPatrons() {
        patronRepository.deleteAll();
    }

    public Patron updatePatron(Long id, Patron updatedPatron) {
        // Find the patron by ID
        Patron existingPatron = patronRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Patron not found"));

        // Update the patron's details
        existingPatron.setName(updatedPatron.getName());
        existingPatron.setContactInformation(updatedPatron.getContactInformation());

        // Save the updated patron
        return patronRepository.save(existingPatron);
    }
}