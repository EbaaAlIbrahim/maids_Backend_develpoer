package com.librarymanagementsystem.library_management_system.repository;

import com.librarymanagementsystem.library_management_system.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
    // Additional query methods (if needed) can be defined here
}
