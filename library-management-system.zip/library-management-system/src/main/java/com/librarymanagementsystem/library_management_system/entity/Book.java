package com.librarymanagementsystem.library_management_system.entity;


import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key

    private String title;  // Title of the book
    private String author;  // Author's name
    private int publicationYear;  // Publication year of the book
    private String isbn;  // ISBN number (unique identifier for books)
}
