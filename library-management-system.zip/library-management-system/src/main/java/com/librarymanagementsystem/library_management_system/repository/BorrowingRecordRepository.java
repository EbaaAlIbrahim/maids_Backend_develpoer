package com.librarymanagementsystem.library_management_system.repository;

import com.librarymanagementsystem.library_management_system.entity.Book;
import com.librarymanagementsystem.library_management_system.entity.Patron;
import com.librarymanagementsystem.library_management_system.entity.BorrowingRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface BorrowingRecordRepository extends JpaRepository<BorrowingRecord, Long> {
    // This method checks for a BorrowingRecord by book and patron
    Optional<BorrowingRecord> findByBookAndPatron(Book book, Patron patron);
}
