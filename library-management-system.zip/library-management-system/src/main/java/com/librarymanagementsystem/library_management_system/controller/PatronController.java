package com.librarymanagementsystem.library_management_system.controller;

import com.librarymanagementsystem.library_management_system.entity.Patron;
import com.librarymanagementsystem.library_management_system.service.PatronService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patrons")
public class PatronController {

    @Autowired
    private PatronService patronService; // Correctly inject the PatronService

    @PostMapping
    public ResponseEntity<Patron> createPatron(@RequestBody Patron patron) {
        // Call the addPatron method from the injected PatronService
        Patron savedPatron = patronService.addPatron(patron);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPatron);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Patron> updatePatron(
        @PathVariable Long id, 
        @RequestBody Patron updatedPatron
    ) {
        Patron savedPatron = patronService.updatePatron(id, updatedPatron);
        return ResponseEntity.ok(savedPatron);
    }

    // Get all patrons
    @GetMapping
    public ResponseEntity<List<Patron>> getAllPatrons() {
        List<Patron> patrons = patronService.getAllPatrons();
        return ResponseEntity.ok(patrons);
    }

    // Get a patron by ID
    @GetMapping("/{id}")
    public ResponseEntity<Patron> getPatronById(@PathVariable Long id) {
        Patron patron = patronService.getPatronById(id);
        return ResponseEntity.ok(patron);
    }

    // Delete a patron by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePatronById(@PathVariable Long id) {
        patronService.deletePatronById(id);
        return ResponseEntity.ok("Patron deleted successfully");
    }

    // Delete all patrons
    @DeleteMapping
    public ResponseEntity<String> deleteAllPatrons() {
        patronService.deleteAllPatrons();
        return ResponseEntity.ok("All patrons deleted successfully");
    }
    
}
