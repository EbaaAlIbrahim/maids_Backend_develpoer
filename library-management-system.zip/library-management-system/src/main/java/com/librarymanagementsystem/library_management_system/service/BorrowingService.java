package com.librarymanagementsystem.library_management_system.service;

import com.librarymanagementsystem.library_management_system.entity.Book;
import com.librarymanagementsystem.library_management_system.entity.Patron;
import com.librarymanagementsystem.library_management_system.entity.BorrowingRecord;
import com.librarymanagementsystem.library_management_system.repository.BookRepository;
import com.librarymanagementsystem.library_management_system.repository.PatronRepository;
import com.librarymanagementsystem.library_management_system.repository.BorrowingRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BorrowingService {

    @Autowired
    private BorrowingRecordRepository borrowingRecordRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private PatronRepository patronRepository;

    // Method to borrow a book
    public void borrowBook(Long bookId, Long patronId) {
        // Fetch the book and patron by their IDs
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        Patron patron = patronRepository.findById(patronId)
                .orElseThrow(() -> new RuntimeException("Patron not found"));

        // Check if the book is already borrowed by this patron
        Optional<BorrowingRecord> existingRecord = borrowingRecordRepository.findByBookAndPatron(book, patron);
        if (existingRecord.isPresent()) {
            throw new RuntimeException("This book is already borrowed by the patron.");
        }

        // Create a new borrowing record
        BorrowingRecord newRecord = new BorrowingRecord();
        newRecord.setBook(book);
        newRecord.setPatron(patron);
        newRecord.setBorrowingDate(java.time.LocalDate.now()); // assuming borrowing date is today

        // Save the new borrowing record
        borrowingRecordRepository.save(newRecord);
    }

    // Method to return a book
    public void returnBook(Long bookId, Long patronId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        Patron patron = patronRepository.findById(patronId)
                .orElseThrow(() -> new RuntimeException("Patron not found"));
    
        BorrowingRecord record = borrowingRecordRepository.findByBookAndPatron(book, patron)
                .orElseThrow(() -> new RuntimeException("Borrowing record not found"));
    
        record.setReturnDate(java.time.LocalDate.now());
        borrowingRecordRepository.save(record);
    }
    
}
